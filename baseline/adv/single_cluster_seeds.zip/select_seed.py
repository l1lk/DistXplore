import numpy as np
import keras
import tensorflow
import os


(X_train, y_train), _ = keras.datasets.mnist.load_data()
X_train = X_train.reshape(len(X_train), -1)

for i in range(1):
    save_dir = "/data/wlt/projects/ga_attack/single_cluster_seeds/mnist/training_300_%s"%i
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        
    for label in np.unique(y_train):
        temp_x = X_train[np.where(y_train==label)[0]]
        select_index = np.random.choice(len(temp_x), 300, replace=False)
        temp_x = temp_x[select_index]
        print(temp_x.shape)
        np.save(os.path.join(save_dir, "class_%s_seed.npy"%label), temp_x)

